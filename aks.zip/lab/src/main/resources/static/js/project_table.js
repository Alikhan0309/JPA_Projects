function executeSearch() {
    var input, filter, table, tr, td, i, j, txtValue;
    input = document.getElementById("searchInput");
    filter = input.value.toUpperCase();  // Приведение к верхнему регистру для сравнения
    var columnIndex = document.getElementById("searchColumn").selectedIndex;

    table = document.querySelector(".data-table");
    tr = table.getElementsByTagName("tr");

    // Перебор всех строк таблицы
    for (i = 1; i < tr.length; i++) {
        let displayRow = false; // Переменная для контроля отображения строки

        // Получение всех ячеек текущей строки
        td = tr[i].getElementsByTagName("td");

        // Проверка, поиск по всем столбцам или по конкретному
        if (columnIndex === 0) { // Если выбраны "Все столбцы"
            for (j = 0; j < td.length; j++) {
                txtValue = td[j].textContent || td[j].innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    displayRow = true;
                    break;
                }
            }
        } else { // Поиск по конкретному столбцу
            if (td[columnIndex - 1]) {
                txtValue = td[columnIndex - 1].textContent || td[columnIndex - 1].innerText;
                // Проверка на полное соответствие текста
                if (columnIndex - 1 == 0) { // Проверка по ID
                    if (txtValue.toUpperCase() === filter) {
                        displayRow = true;
                    }
                } else { // Поиск по другим столбцам
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        displayRow = true;
                    }
                }
            }
        }

        tr[i].style.display = displayRow ? "" : "none"; // Применение стиля отображения в зависимости от результата поиска
    }
}

function sortTable(columnIndex) {
    var table, rows, switching, i, x, y, shouldSwitch, dir, switchCount = 0;
    table = document.querySelector(".data-table");
    switching = true;
    dir = "asc"; // Начальное направление сортировки

    while (switching) {
        switching = false;
        rows = table.getElementsByTagName("TR");

        for (i = 1; i < (rows.length - 1); i++) {
            shouldSwitch = false;
            x = rows[i].getElementsByTagName("TD")[columnIndex];
            y = rows[i + 1].getElementsByTagName("TD")[columnIndex];

            // Проверка, нужно ли рассматривать значения как числа
            var xVal = x.textContent || x.innerText;
            var yVal = y.textContent || y.innerText;

            // Проверяем, является ли содержимое столбца числовым
            if (!isNaN(parseFloat(xVal)) && !isNaN(parseFloat(yVal))) {
                xVal = parseFloat(xVal);
                yVal = parseFloat(yVal);
            }

            if (dir == "asc") {
                if (xVal > yVal) {
                    shouldSwitch = true;
                    break;
                }
            } else if (dir == "desc") {
                if (xVal < yVal) {
                    shouldSwitch = true;
                    break;
                }
            }
        }
        if (shouldSwitch) {
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
            switchCount++;
        } else {
            if (switchCount === 0 && dir === "asc") {
                dir = "desc";
                switching = true;
            }
        }
    }
}


function openModal(isEdit = false, element = null) {
    var modal = document.getElementById("myModal");
    var form = document.getElementById("modalForm");
    var title = document.getElementById("modalTitle");
    var formMethod = document.getElementById("formMethod");
    form.reset();
    title.textContent = isEdit ? "Edit Project" : "Add New Project";
    form.action = isEdit ? "/Projects/updateProject" : "/projects/insert";
    formMethod.value = isEdit ? "PUT" : "POST";
    if (isEdit) {
        document.getElementById("projectId").value = element.getAttribute("data-id");
        document.getElementById("projectName").value = element.getAttribute("data-name");
        document.getElementById("startDate").value = element.getAttribute("data-startDate");
        document.getElementById("endDate").value = element.getAttribute("data-endDate");
        document.getElementById("projectDescription").value = element.getAttribute("data-description");
    }
    modal.style.display = "block";
}

function closeModal() {
    var modal = document.getElementById("myModal");
    modal.style.display = "none";
}

function submitForm() {
    var form = document.getElementById("modalForm");
    form.submit();
}

function fetchProjectResults() {
    const projectId = document.getElementById("projectIdInput").value.trim();
    if (projectId) {
        fetch(`/projects/results/${projectId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Server responded with status ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                displayResults(data); // Function to display the results in the modal
            })
            .catch(error => {
                console.error('Error fetching project results:', error);
                alert('Failed to fetch project results. See console for details.');
            });
    } else {
        alert("Please enter a valid Project ID.");
    }
}

function displayResults(data) {
    const tbody = document.getElementById('resultsContent');
    tbody.innerHTML = ''; // Clear previous content
    data.forEach(item => {
        const tr = document.createElement('tr');
        item.forEach(cell => {
            const td = document.createElement('td');
            td.textContent = cell; // Set cell text content to data
            tr.appendChild(td);
        });
        tbody.appendChild(tr); // Append the row to the table body
    });
    openResultsModal(); // Open the modal to show the results
}

function openResultsModal() {
    const modal = document.getElementById('resultsModal');
    modal.style.display = 'block';
}

function closeResultsModal() {
    const modal = document.getElementById('resultsModal');
    modal.style.display = 'none';
}

function showQueryResults() {
    fetch('/api/query-results')
        .then(response => response.json())
        .then(data => {
            const tbody = document.getElementById('queryResultsContent');
            tbody.innerHTML = ''; // Очистка текущих данных
            data.forEach(item => {
                const tr = document.createElement('tr');
                item.forEach(cell => {
                    const td = document.createElement('td');
                    td.textContent = cell;
                    tr.appendChild(td);
                });
                tbody.appendChild(tr);
            });
            openQueryResultsModal(); // Открытие модального окна
        })
        .catch(error => console.error('Error fetching query results:', error));
}

function openQueryResultsModal() {
    const modal = document.getElementById('queryResultsModal');
    modal.style.display = 'block';
}

function closeQueryResultsModal() {
    const modal = document.getElementById('queryResultsModal');
    modal.style.display = 'none';
}
