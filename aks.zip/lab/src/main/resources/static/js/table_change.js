document.addEventListener('DOMContentLoaded', function () {
    const buttons = document.querySelectorAll('button[data-table]');
    buttons.forEach(button => button.addEventListener('click', function () {
        toggleTables(this.getAttribute('data-table'));
    }));

    function toggleTables(name) {
        const tables = ['PatientTable', 'FunctionTable', 'SelectTable','SearchTable'];
        tables.forEach(tableId => {
            const table = document.getElementById(tableId);
            table.style.display = (tableId === name) ? 'table' : 'none';
        });
    }
    document.querySelectorAll('th').forEach(th => th.addEventListener('click', function() {
        sortTable(Array.from(th.parentNode.children).indexOf(th));
    }));
});