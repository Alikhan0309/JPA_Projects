package IS2021.lab1.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
@Entity(name = "Results")
@Getter
@Setter
public class Results {
    @Id
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "project_id")
    private Projects project;

    @Column(name = "achieved_goals", columnDefinition = "TEXT")
    private String achievedGoals;

    @Column(name = "impact_assessment", columnDefinition = "TEXT")
    private String impactAssessment;

    @Column(name = "lessons_learned", columnDefinition = "TEXT")
    private String lessonsLearned;
}
