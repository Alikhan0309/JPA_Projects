package IS2021.lab1.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;
@Entity(name = "EmissionSources")
@Getter
@Setter

public class Emission {
    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "type_of_source")
    private String typeOfSource;

    @Column(name = "emission_quantity")
    private Double emissionQuantity;

    @Column(name = "percentage_of_total_emissions")
    private Double percentageOfTotalEmissions;

    @Column(name = "pollutant_levels")
    private String pollutantLevels;
}
