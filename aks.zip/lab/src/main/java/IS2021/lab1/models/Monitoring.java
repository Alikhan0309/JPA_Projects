package IS2021.lab1.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Entity(name = "Monitoring")
@Getter
@Setter
public class Monitoring {
    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "geographical_location")
    private String geographicalLocation;

    @Column(name = "pollutant_levels")
    private String pollutantLevels;

    @Column(name = "measurement_date")
    private LocalDate measurementDate;

    @Column(name = "data_source")
    private String dataSource;
}

