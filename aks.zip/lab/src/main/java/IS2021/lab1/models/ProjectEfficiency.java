package IS2021.lab1.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
@Entity(name = "ProjectEfficiency")
@Getter
@Setter
public class ProjectEfficiency {
    @Id
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "project_id")
    private Projects project;

    @Column(name = "key_performance_indicators", columnDefinition = "TEXT")
    private String keyPerformanceIndicators;

    @Column(name = "performance_data", columnDefinition = "TEXT")
    private String performanceData;
}
