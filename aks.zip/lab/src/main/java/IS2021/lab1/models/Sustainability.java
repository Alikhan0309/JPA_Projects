package IS2021.lab1.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;
@Entity(name = "Sustainability")
@Getter
@Setter

public class Sustainability {
    @Id

    @Column(name = "id")
    private Long id;

    @Column(name = "eco_programs_and_initiatives", columnDefinition = "TEXT")
    private String ecoProgramsAndInitiatives;

    @Column(name = "innovative_technologies", columnDefinition = "TEXT")
    private String innovativeTechnologies;

    @Column(name = "energy_efficiency")
    private String energyEfficiency;

    @Column(name = "green_initiatives", columnDefinition = "TEXT")
    private String greenInitiatives;
}
