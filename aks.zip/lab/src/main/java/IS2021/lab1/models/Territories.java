package IS2021.lab1.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;
@Entity(name = "Territories")
@Getter
@Setter
public class Territories {
    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "territory_name")
    private String territoryName;

    @Column(name = "geographical_information", columnDefinition = "TEXT")
    private String geographicalInformation;

    @Column(name = "land_use")
    private String landUse;

    @Column(name = "environmental_status", columnDefinition = "TEXT")
    private String environmentalStatus;
}

