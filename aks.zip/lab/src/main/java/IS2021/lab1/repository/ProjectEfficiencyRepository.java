package IS2021.lab1.repository;

import IS2021.lab1.models.ProjectEfficiency;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectEfficiencyRepository extends JpaRepository<ProjectEfficiency, Long> {
}
