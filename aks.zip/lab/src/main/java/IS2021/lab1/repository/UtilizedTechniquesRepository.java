package IS2021.lab1.repository;


import IS2021.lab1.models.UtilizedTechniques;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UtilizedTechniquesRepository extends JpaRepository<UtilizedTechniques, Long> {
}
