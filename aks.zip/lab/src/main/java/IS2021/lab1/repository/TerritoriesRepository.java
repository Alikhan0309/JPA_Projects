package IS2021.lab1.repository;

import IS2021.lab1.models.Territories;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TerritoriesRepository extends JpaRepository<Territories, Long> {
}

