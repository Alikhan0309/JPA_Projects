package IS2021.lab1.repository;
import IS2021.lab1.models.Sustainability;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SustainabilityRepository extends JpaRepository<Sustainability, Long> {
}
