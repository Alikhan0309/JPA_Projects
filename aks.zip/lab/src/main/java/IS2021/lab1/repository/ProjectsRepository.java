package IS2021.lab1.repository;

import IS2021.lab1.models.Projects;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProjectsRepository extends JpaRepository<Projects, Long> {
    @Query(value = "SELECT * FROM get_project_results(:project_id)", nativeQuery = true)
    List<Object[]> get_function_results(@Param("project_id") int project_id);


    @Query(value = "SELECT pe.id, pe.project_id, p.project_name, pe.key_performance_indicators, pe.performance_data FROM project_efficiency pe JOIN projects p ON pe.project_id = p.id ", nativeQuery = true)
    List<Object[]> get_query_results();

    @Query(value = "select * from get_projects_info()", nativeQuery = true)
    List<Object[]> get_cursor();
}

