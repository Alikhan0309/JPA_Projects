package IS2021.lab1.controller;

import IS2021.lab1.models.*;
import IS2021.lab1.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class MainController {

    private final EmissionRepository emissionRepository;
    private final MonitoringRepository monitoringRepository;
    private final ProjectEfficiencyRepository projectEfficiencyRepository;
    private final SustainabilityRepository sustainabilityRepository;
    private final ProjectsRepository projectsRepository;
    private final ResultsRepository resultsRepository;
    private final TerritoriesRepository territoriesRepository;
    private final UtilizedTechniquesRepository utilizedTechniquesRepository;
    private final LogsRepository logsRepository;

    @Autowired
    public MainController(EmissionRepository emissionRepository,
                          MonitoringRepository monitoringRepository,
                          ProjectEfficiencyRepository projectEfficiencyRepository,
                          SustainabilityRepository sustainabilityRepository,
                          ProjectsRepository projectsRepository,
                          ResultsRepository resultsRepository,
                          TerritoriesRepository territoriesRepository,
                          UtilizedTechniquesRepository utilizedTechniquesRepository,
                          LogsRepository logsRepository) {
        this.emissionRepository = emissionRepository;
        this.monitoringRepository = monitoringRepository;
        this.projectEfficiencyRepository = projectEfficiencyRepository;
        this.sustainabilityRepository = sustainabilityRepository;
        this.projectsRepository = projectsRepository;
        this.resultsRepository = resultsRepository;
        this.territoriesRepository = territoriesRepository;
        this.utilizedTechniquesRepository = utilizedTechniquesRepository;
        this.logsRepository = logsRepository;
    }

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/changeLogs")
    public String getLogs(Model model) {
        List<ChangeLog> list = logsRepository.findAll();
        model.addAttribute("changelogs",list);
        return "/changeLogs";
    }

    @GetMapping("/Emission/emission")
    public String getEmission(Model model) {
        List<Emission> treatments = emissionRepository.findAll();
        model.addAttribute("emissions", treatments);
        return "/Emission/emission";
    }

    @GetMapping("/Emission/addEmission")
    public String addEmissionForm(Model model) {
        model.addAttribute("emissions",new Emission());
        return "/Emission/addEmission";
    }

    @PostMapping("emission/insert")
    public String addEmission(@ModelAttribute Emission emission) {
        emissionRepository.save(emission);
        return  "redirect:/Emission/emission";
    }
    @PostMapping("/Emission/updateEmission")
    public String updateEmission(@ModelAttribute Emission emission) {
        emissionRepository.save(emission);
        return  "redirect:/Emission/emission";
    }
    @GetMapping("/updateEmission/{id}")
    public String updateEmissionForm(@PathVariable Long id, Model model) {
        Emission e = emissionRepository.findById(id).orElse(null);
        model.addAttribute("emisson",e);
        return "/Emission/updateEmission";
    }

    @PostMapping("/emission/delete/{id}")
    public String deleteEmission(@PathVariable Long id) {
        emissionRepository.deleteById(id);
        return "redirect:/Emission/emission";
    }

    @GetMapping("/Monitoring/monitoring")
    public String getMonitoring(Model model) {
        List<Monitoring> monitoringData = monitoringRepository.findAll();
        model.addAttribute("monitoringData", monitoringData);
        return "/Monitoring/monitoring";
    }

    @GetMapping("/Monitoring/addMonitoring")
    public String addMonitoringForm(Model model) {
        model.addAttribute("monitoringData", new Monitoring());
        return "/Monitoring/addMonitoring";
    }

    @PostMapping("/Monitoring/insert")
    public String addMonitoring(@ModelAttribute Monitoring monitoring) {
        monitoringRepository.save(monitoring);
        return "redirect:/Monitoring/monitoring";
    }

    @PostMapping("/Monitoring/updateMonitoring")
    public String updateMonitoring(@ModelAttribute Monitoring monitoring) {
        monitoringRepository.save(monitoring);
        return "redirect:/Monitoring/monitoring";
    }

    @GetMapping("/updateMonitoring/{id}")
    public String updateMonitoringForm(@PathVariable Long id, Model model) {
        Monitoring m = monitoringRepository.findById(id).orElse(null);
        model.addAttribute("monitoringData", m);
        return "/Monitoring/updateMonitoring";
    }

    @PostMapping("/monitoring/delete/{id}")
    public String deleteMonitoring(@PathVariable Long id) {
        monitoringRepository.deleteById(id);
        return "redirect:/Monitoring/monitoring";
    }

    @GetMapping("/ProjectEfficiency/projectEfficiency")
    public String getProjectEfficiency(Model model) {
        List<ProjectEfficiency> projectEfficiencyList = projectEfficiencyRepository.findAll();
        model.addAttribute("efficiencies", projectEfficiencyList);
        return "/ProjectEfficiency/projectEfficiency";
    }

    @GetMapping("/ProjectEfficiency/addPE")
    public String addProjectEfficiencyForm(Model model) {
        model.addAttribute("projectEfficiency", new ProjectEfficiency());
        return "/ProjectEfficiency/addPE";
    }

    @PostMapping("/ProjectEfficiency/insert")
    public String addProjectEfficiency(@ModelAttribute ProjectEfficiency projectEfficiency) {
        projectEfficiencyRepository.save(projectEfficiency);
        return "redirect:/ProjectEfficiency/projectEfficiency";
    }

    @PostMapping("/ProjectEfficiency/updatePE")
    public String updateProjectEfficiency(@ModelAttribute ProjectEfficiency projectEfficiency) {
        projectEfficiencyRepository.save(projectEfficiency);
        return "redirect:/ProjectEfficiency/projectEfficiency";
    }

    @GetMapping("/ProjectEfficiency/update/{id}")
    public String updateProjectEfficiencyForm(@PathVariable Long id, Model model) {
        ProjectEfficiency projectEfficiency = projectEfficiencyRepository.findById(id).orElse(null);
        model.addAttribute("projectEfficiency", projectEfficiency);
        return "/ProjectEfficiency/updatePE";
    }

    @PostMapping("/ProjectEfficiency/delete/{id}")
    public String deleteProjectEfficiency(@PathVariable Long id) {
        projectEfficiencyRepository.deleteById(id);
        return "redirect:/ProjectEfficiency/projectEfficiency";
    }

    @GetMapping("/Projects/projects")
    public String getProject(Model model) {
        addProjectAttributes(model);
        return "/Projects/projects";
    }

    @GetMapping("/projects/results/{projectId}")
    @ResponseBody
    public List<Object[]> getProjectResults(@PathVariable int projectId) {
        // Вызываем вашу функцию и возвращаем результаты
        return projectsRepository.get_function_results(projectId);
    }

    @GetMapping("/api/query-results")
    public ResponseEntity<List<Object[]>> getQueryResults() {
        List<Object[]> results = projectsRepository.get_query_results();
        return ResponseEntity.ok(results); // This will return JSON data
    }


    private void addProjectAttributes(Model model) {
        List<Projects> projects = projectsRepository.findAll();
        model.addAttribute("projects", projects);
        List<Object[]> cursor = projectsRepository.get_cursor();
        model.addAttribute("cursor",cursor);
    }


    @GetMapping("/Projects/addProject")
    public String addProjectForm(Model model) {
        model.addAttribute("project",new Projects());
        return "/Projects/addProject";
    }
    @PostMapping("projects/insert")
    public String addProject(@ModelAttribute Projects project) {
        projectsRepository.save(project);
        return  "redirect:/Projects/projects";
    }
    @PostMapping("/Projects/updateProject")
    public String updateProject(@ModelAttribute Projects project) {
        projectsRepository.save(project);
        return  "redirect:/Projects/projects";
    }
    @GetMapping("/updateProject/{id}")
    public String updateProjectForm(@PathVariable Long id, Model model) {
        Projects p = projectsRepository.findById(id).orElse(null);
        model.addAttribute("project",p);
        return "/Projects/updateProject";
    }
    @PostMapping("/projects/delete/{id}")
    public String deleteProject(@PathVariable Long id) {
        projectsRepository.deleteById(id);
        return "redirect:/Projects/projects";
    }

    @GetMapping("/Results/results")
    public String getResults(Model model) {
        List<Results> results = resultsRepository.findAll();
        model.addAttribute("results", results);
        return "/Results/results";
    }

    @GetMapping("/Results/addResult")
    public String addResultForm(Model model) {
        model.addAttribute("result", new Results());
        return "/Results/addResult";
    }

    @PostMapping("/Results/insert")
    public String addResult(@ModelAttribute Results result) {
        resultsRepository.save(result);
        return "redirect:/Results/results";
    }

    @PostMapping("/Results/updateResult")
    public String updateResult(@ModelAttribute Results result) {
        resultsRepository.save(result);
        return "redirect:/Results/results";
    }

    @GetMapping("/updateResult/{id}")
    public String updateResultForm(@PathVariable Long id, Model model) {
        Results r = resultsRepository.findById(id).orElse(null);
        model.addAttribute("result", r);
        return "/Results/updateResult";
    }

    @PostMapping("/Results/delete/{id}")
    public String deleteResult(@PathVariable Long id) {
        resultsRepository.deleteById(id);
        return "redirect:/Results/results";
    }
    @GetMapping("/Sustainability/sustainability")
    public String getSustainabilities(Model model) {
        List<Sustainability> sustainabilities = sustainabilityRepository.findAll();
        model.addAttribute("sustainabilities", sustainabilities);
        return "/Sustainability/sustainability";
    }

    @GetMapping("/Sustainability/addSus")
    public String addSustainabilityForm(Model model) {
        model.addAttribute("sustainability", new Sustainability());
        return "/Sustainability/addSus";
    }

    @PostMapping("/Sustainability/insert")
    public String addSustainability(@ModelAttribute Sustainability sustainability) {
        sustainabilityRepository.save(sustainability);
        return "redirect:/Sustainability/sustainability";
    }

    @PostMapping("/Sustainability/updateSus")
    public String updateSustainability(@ModelAttribute Sustainability sustainability) {
        sustainabilityRepository.save(sustainability);
        return "redirect:/Sustainability/sustainability";
    }

    @GetMapping("/updateSus/{id}")
    public String updateSustainabilityForm(@PathVariable Long id, Model model) {
        Sustainability s = sustainabilityRepository.findById(id).orElse(null);
        model.addAttribute("sustainability", s);
        return "/Sustainability/updateSus";
    }

    @PostMapping("/Sustainability/delete/{id}")
    public String deleteSustainability(@PathVariable Long id) {
        sustainabilityRepository.deleteById(id);
        return "redirect:/Sustainability/sustainability";
    }
    @GetMapping("/Territories/territories")
    public String getTerritories(Model model) {
        List<Territories> territories = territoriesRepository.findAll();
        model.addAttribute("territories", territories);
        return "/Territories/territories";
    }

    @GetMapping("/Territories/addTerritory")
    public String addTerritoryForm(Model model) {
        model.addAttribute("territory", new Territories());
        return "/Territories/addTerritory";
    }

    @PostMapping("/Territories/insert")
    public String addTerritory(@ModelAttribute Territories territory) {
        territoriesRepository.save(territory);
        return "redirect:/Territories/territories";
    }

    @PostMapping("/Territories/updateTerritory")
    public String updateTerritory(@ModelAttribute Territories territory) {
        territoriesRepository.save(territory);
        return "redirect:/Territories/territories";
    }

    @GetMapping("/updateTerritory/{id}")
    public String updateTerritoryForm(@PathVariable Long id, Model model) {
        Territories t = territoriesRepository.findById(id).orElse(null);
        model.addAttribute("territory", t);
        return "/Territories/updateTerritory";
    }

    @PostMapping("/Territories/delete/{id}")
    public String deleteTerritory(@PathVariable Long id) {
        territoriesRepository.deleteById(id);
        return "redirect:/Territories/territories";
    }

    @GetMapping("/UtilizedTechniques/utilized")
    public String getTechniques(Model model) {
        List<UtilizedTechniques> techniques = utilizedTechniquesRepository.findAll();
        model.addAttribute("techniques", techniques);
        return "/UtilizedTechniques/utilized";
    }

    @GetMapping("/UtilizedTechniques/addUT")
    public String addTechniqueForm(Model model) {
        model.addAttribute("technique", new UtilizedTechniques());
        return "/UtilizedTechniques/addUT";
    }

    @PostMapping("/UtilizedTechniques/insert")
    public String addTechnique(@ModelAttribute UtilizedTechniques technique) {
        utilizedTechniquesRepository.save(technique);
        return "redirect:/UtilizedTechniques/utilized";
    }

    @PostMapping("/UtilizedTechniques/updateUT")
    public String updateTechnique(@ModelAttribute UtilizedTechniques technique) {
        utilizedTechniquesRepository.save(technique);
        return "redirect:/UtilizedTechniques/utilized";
    }

    @GetMapping("/updateUTech/{id}")
    public String updateTechniqueForm(@PathVariable Long id, Model model) {
        UtilizedTechniques t = utilizedTechniquesRepository.findById(id).orElse(null);
        model.addAttribute("technique", t);
        return "/UtilizedTechniques/updateUT";
    }

    @PostMapping("/UtilizedTechniques/delete/{id}")
    public String deleteTechnique(@PathVariable Long id) {
        utilizedTechniquesRepository.deleteById(id);
        return "redirect:/UtilizedTechniques/utilized";
    }
}
