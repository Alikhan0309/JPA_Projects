package com.example.demo.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity(name = "Manufacturers")
public class Manufacturer {
    @Id
    @Column(name = "manufacturer_id")
    private Long manufacturerId;

    @Column(name = "name")
    private String name;

    @Column(name = "location")
    private String location;
}
