package com.example.demo.controller;
import com.example.demo.models.*;
import com.example.demo.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
@Controller
public class MainController {
    private final CustomerRepository customerRepository;
    private final CategoryRepository categoryRepository;
    private final ManufacturerRepository manufacturerRepository;

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;

    @Autowired
    public MainController(CustomerRepository customerRepository,CategoryRepository categoryRepository,
                          ManufacturerRepository manufacturerRepository,  OrderRepository orderRepository,
                          ProductRepository productRepository) {
        this.categoryRepository = categoryRepository;
        this.customerRepository = customerRepository;
        this.manufacturerRepository = manufacturerRepository;
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
    }
    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/customer")
    public String getCutomer(Model model) {
        List<Customer> customers = customerRepository.findAll();
        model.addAttribute("customers",customers);
        return "/customer";
    }
    @PostMapping("/customers/insert")
    public String addKatysushlarTizimi(@ModelAttribute Customer customer) {
        customerRepository.save(customer);
        return "redirect:/customer";
    }
    @PostMapping("/customers/update")
    public String updateKatysushlarTizimi(@ModelAttribute Customer customer) {
        customerRepository.save(customer);
        return "redirect:/customer";
    }
    @PostMapping("/customers/delete/{id}")
    public String deleteKatysushlarTizimi(@PathVariable Long id) {
        customerRepository.deleteById(id);
        return "redirect:/customer";
    }

    @GetMapping("/category")
    public String getCategories(Model model) {
        List<Category> categories = categoryRepository.findAll();
        model.addAttribute("categories", categories);
        return "/category";
    }

    @PostMapping("/category/insert")
    public String addCategory(@ModelAttribute Category category) {
        categoryRepository.save(category);
        return "redirect:/category";
    }

    @PostMapping("/category/update")
    public String updateCategory(@ModelAttribute Category category) {
        categoryRepository.save(category);
        return "redirect:/category";
    }

    @PostMapping("/category/delete/{id}")
    public String deleteCategory(@PathVariable Long id) {
        categoryRepository.deleteById(id);
        return "redirect:/category";
    }

    @GetMapping("/manufacturer")
    public String getManufacturers(Model model) {
        List<Manufacturer> manufacturers = manufacturerRepository.findAll();
        model.addAttribute("manufacturers", manufacturers);
        return "/manufacturer";
    }

    @PostMapping("/manufacturer/insert")
    public String addManufacturer(@ModelAttribute Manufacturer manufacturer) {
        manufacturerRepository.save(manufacturer);
        return "redirect:/manufacturer";
    }

    @PostMapping("/manufacturer/update")
    public String updateManufacturer(@ModelAttribute Manufacturer manufacturer) {
        manufacturerRepository.save(manufacturer);
        return "redirect:/manufacturer";
    }

    @PostMapping("/manufacturer/delete/{id}")
    public String deleteManufacturer(@PathVariable Long id) {
        manufacturerRepository.deleteById(id);
        return "redirect:/manufacturer";
    }

    @GetMapping("/order")
    public String getOrders(Model model) {
        List<Order> orders = orderRepository.findAll();
        List<Customer> customers = customerRepository.findAll();
        model.addAttribute("orders", orders);
        model.addAttribute("customers", customers);
        return "/order";
    }

    @PostMapping("/order/insert")
    public String addOrder(@ModelAttribute Order order) {
        orderRepository.save(order);
        return "redirect:/order";
    }

    @PostMapping("/order/update")
    public String updateOrder(@ModelAttribute Order order) {
        orderRepository.save(order);
        return "redirect:/order";
    }

    @PostMapping("/order/delete/{id}")
    public String deleteOrder(@PathVariable Long id) {
        orderRepository.deleteById(id);
        return "redirect:/order";
    }

    @GetMapping("/product")
    public String getProducts(Model model) {
        List<Product> products = productRepository.findAll();
        model.addAttribute("products", products);
        List<Category> categories = categoryRepository.findAll();
        model.addAttribute("categories", categories);
        List<Manufacturer> manufacturers = manufacturerRepository.findAll();
        model.addAttribute("manufacturers", manufacturers);
        return "/product";
    }

    @PostMapping("/product/insert")
    public String addProduct(@ModelAttribute Product product) {
        productRepository.save(product);
        return "redirect:/product";
    }

    @PostMapping("/product/update")
    public String updateProduct(@ModelAttribute Product product) {
        productRepository.save(product);
        return "redirect:/product";
    }

    @PostMapping("/product/delete/{id}")
    public String deleteProduct(@PathVariable Long id) {
        productRepository.deleteById(id);
        return "redirect:/product";
    }

}
