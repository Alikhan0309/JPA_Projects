document.addEventListener('DOMContentLoaded', function () {
    const buttons = document.querySelectorAll('button[data-table]');
    buttons.forEach(button => button.addEventListener('click', function () {
        toggleTables(this.getAttribute('data-table'));
    }));
    function toggleTables(name) {
        const tables = ['cursor_table','select_table', 'tizim_table'];
        tables.forEach(tableId => {
            const table = document.getElementById(tableId);
            table.style.display = (tableId === name) ? 'table' : 'none';
        });
    }
});

function executeSearch() {
    var input, filter, table, tr, td, i, j, txtValue;
    input = document.getElementById("searchInput");
    filter = input.value.toUpperCase();  // Приведение к верхнему регистру для сравнения
    var columnIndex = document.getElementById("searchColumn").selectedIndex;

    table = document.querySelector(".data-table");
    tr = table.getElementsByTagName("tr");

    // Перебор всех строк таблицы
    for (i = 1; i < tr.length; i++) {
        let displayRow = false; // Переменная для контроля отображения строки

        // Получение всех ячеек текущей строки
        td = tr[i].getElementsByTagName("td");

        // Проверка, поиск по всем столбцам или по конкретному
        if (columnIndex === 0) { // Если выбраны "Все столбцы"
            for (j = 0; j < td.length; j++) {
                txtValue = td[j].textContent || td[j].innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    displayRow = true;
                    break;
                }
            }
        } else { // Поиск по конкретному столбцу
            if (td[columnIndex - 1]) {
                txtValue = td[columnIndex - 1].textContent || td[columnIndex - 1].innerText;
                // Проверка на полное соответствие текста
                if (columnIndex - 1 == 0) { // Проверка по ID
                    if (txtValue.toUpperCase() === filter) {
                        displayRow = true;
                    }
                } else { // Поиск по другим столбцам
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        displayRow = true;
                    }
                }
            }
        }

        tr[i].style.display = displayRow ? "" : "none"; // Применение стиля отображения в зависимости от результата поиска
    }
}

function sortTable(columnIndex, tableName) {
    var table, rows, switching, i, x, y, shouldSwitch, dir, switchCount = 0;
    table = document.getElementById(tableName); // Use ID to select the table
    if (!table) return; // Exit if table not found
    switching = true;
    dir = "asc"; // Initial sorting direction

    while (switching) {
        switching = false;
        rows = table.getElementsByTagName("TR");

        for (i = 1; i < (rows.length - 1); i++) {
            shouldSwitch = false;
            x = rows[i].getElementsByTagName("TD")[columnIndex];
            y = rows[i + 1].getElementsByTagName("TD")[columnIndex];

            var xVal = x.textContent || x.innerText;
            var yVal = y.textContent || y.innerText;

            if (!isNaN(parseFloat(xVal)) && !isNaN(parseFloat(yVal))) {
                xVal = parseFloat(xVal);
                yVal = parseFloat(yVal);
            }

            if (dir == "asc") {
                if (xVal > yVal) {
                    shouldSwitch = true;
                    break;
                }
            } else if (dir == "desc") {
                if (xVal < yVal) {
                    shouldSwitch = true;
                    break;
                }
            }
        }
        if (shouldSwitch) {
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
            switchCount++;
        } else {
            if (switchCount == 0 && dir == "asc") {
                dir = "desc";
                switching = true;
            }
        }
    }
}


// Открытие модального окна
function openModal(isEdit, element) {
    var modal = document.getElementById("myModal");
    var form = document.getElementById("modalForm");
    var title = document.getElementById("modalTitle");
    var formMethod = document.getElementById("formMethod");

    // Очистка значений формы
    form.reset();

    if (isEdit) {
        title.textContent = "Edit KatysushlarTizimi";
        form.action = "/katysushlarTizimi/updateKT";
        formMethod.value = "PUT"; // Если ваш сервер поддерживает метод PUT

        document.getElementById("id").value = element.getAttribute("data-id");
        document.getElementById("name").value = element.getAttribute("data-name");
        document.getElementById("type").value = element.getAttribute("data-type");
        document.getElementById("region").value = element.getAttribute("data-region");
        document.getElementById("bankType").value = element.getAttribute("data-bankType");
        document.getElementById("financingType").value = element.getAttribute("data-financingType");
        document.getElementById("builder").value = element.getAttribute("data-builder");
        document.getElementById("applicationSubmissionDate").value = element.getAttribute("data-applicationSubmissionDate");
        document.getElementById("apartmentAcquisitionDate").value = element.getAttribute("data-apartmentAcquisitionDate");
        document.getElementById("numberOfRooms").value = element.getAttribute("data-numberOfRooms");
        document.getElementById("nalichiyeImushchestva").value = element.getAttribute("data-nalichie");
    } else {
        title.textContent = "Add New KatysushlarTizimi";
        form.action = "/katysushlarTizimi/insert";
        formMethod.value = "POST";
    }

    modal.style.display = "block";
}


// Закрытие модального окна при нажатии на крестик
function closeModal() {
    var modal = document.getElementById("myModal");
    modal.style.display = "none";
}

// Закрытие модального окна при нажатии вне его области
window.onclick = function (event) {
    var modal = document.getElementById("myModal");
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
document.onkeydown = function (evt) {
    evt = evt || window.event;
    var isEscape = false;
    if ("key" in evt) {
        isEscape = (evt.key === "Escape" || evt.key === "Esc");
    } else {
        isEscape = (evt.keyCode === 27);
    }
    if (isEscape && modal.style.display === "block") {
        closeModal();
    }
};
function fetchModalData(url) {
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json(); // Expecting the server to return JSON
        })
        .then(data => {
            displayDataInModal(data); // Call to display data in modal
        })
        .catch(error => {
            console.error('Fetch operation error:', error);
            alert('Error fetching data. See console for details.');
        });
}

function displayDataInModal(data) {
    const dataResult = document.getElementById('dataResult');
    dataResult.textContent = "Number of People: " + data; // Adjust according to your data structure
    openDataModal(); // Function to open the modal
}

function openDataModal() {
    const modal = document.getElementById('dataModal');
    modal.style.display = "block";
}

function closeDataModal() {
    const modal = document.getElementById('dataModal');
    modal.style.display = "none";
}

// Close modal on click outside
window.onclick = function(event) {
    const modal = document.getElementById('dataModal');
    if (event.target === modal) {
        modal.style.display = "none";
    }
}

// Close modal on escape key
document.onkeydown = function(event) {
    event = event || window.event;
    var isEscape = event.key === "Escape" || event.key === "Esc";
    if (isEscape) {
        closeDataModal();
    }
}

function closeMessage() {
    var messageDiv = document.querySelector('.message');
    messageDiv.style.display = 'none';
}

document.addEventListener("DOMContentLoaded", function() {
    var errorMessage = document.querySelector('.message').innerText.trim();
    if(errorMessage === "") {
        var closeButton = document.querySelector('.close-btn');
        closeButton.style.display = 'none';
    }
});
