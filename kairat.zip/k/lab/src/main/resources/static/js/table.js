function executeSearch() {
    var input, filter, table, tr, td, i, j, txtValue;
    input = document.getElementById("searchInput");
    filter = input.value.toUpperCase();  // Приведение к верхнему регистру для сравнения
    var columnIndex = document.getElementById("searchColumn").selectedIndex;

    table = document.querySelector(".data-table");
    tr = table.getElementsByTagName("tr");

    // Перебор всех строк таблицы
    for (i = 1; i < tr.length; i++) {
        let displayRow = false; // Переменная для контроля отображения строки

        // Получение всех ячеек текущей строки
        td = tr[i].getElementsByTagName("td");

        // Проверка, поиск по всем столбцам или по конкретному
        if (columnIndex === 0) { // Если выбраны "Все столбцы"
            for (j = 0; j < td.length; j++) {
                txtValue = td[j].textContent || td[j].innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    displayRow = true;
                    break;
                }
            }
        } else { // Поиск по конкретному столбцу
            if (td[columnIndex - 1]) {
                txtValue = td[columnIndex - 1].textContent || td[columnIndex - 1].innerText;
                // Проверка на полное соответствие текста
                if (columnIndex - 1 == 0) { // Проверка по ID
                    if (txtValue.toUpperCase() === filter) {
                        displayRow = true;
                    }
                } else { // Поиск по другим столбцам
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        displayRow = true;
                    }
                }
            }
        }

        tr[i].style.display = displayRow ? "" : "none"; // Применение стиля отображения в зависимости от результата поиска
    }
}

function sortTable(columnIndex) {
    var table, rows, switching, i, x, y, shouldSwitch, dir, switchCount = 0;
    table = document.querySelector(".data-table");
    switching = true;
    dir = "asc"; // Начальное направление сортировки

    while (switching) {
        switching = false;
        rows = table.getElementsByTagName("TR");

        for (i = 1; i < (rows.length - 1); i++) {
            shouldSwitch = false;
            x = rows[i].getElementsByTagName("TD")[columnIndex];
            y = rows[i + 1].getElementsByTagName("TD")[columnIndex];

            // Проверка, нужно ли рассматривать значения как числа
            var xVal = x.textContent || x.innerText;
            var yVal = y.textContent || y.innerText;

            // Проверяем, является ли содержимое столбца числовым
            if (!isNaN(parseFloat(xVal)) && !isNaN(parseFloat(yVal))) {
                xVal = parseFloat(xVal);
                yVal = parseFloat(yVal);
            }

            if (dir == "asc") {
                if (xVal > yVal) {
                    shouldSwitch = true;
                    break;
                }
            } else if (dir == "desc") {
                if (xVal < yVal) {
                    shouldSwitch = true;
                    break;
                }
            }
        }
        if (shouldSwitch) {
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
            switchCount++;
        } else {
            if (switchCount === 0 && dir === "asc") {
                dir = "desc";
                switching = true;
            }
        }
    }
}
function closeModal() {
    var modal = document.getElementById("myModal");
    modal.style.display = "none";
}

window.onclick = function(event) {
    var modal = document.getElementById("myModal");
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
document.onkeydown = function(evt) {
    evt = evt || window.event;
    var isEscape = false;
    if ("key" in evt) {
        isEscape = evt.key === "Escape" || evt.key === "Esc";
    } else {
        isEscape = evt.keyCode === 27;
    }
    if (isEscape && modal.style.display === "block") {
        closeModal();
    }
};