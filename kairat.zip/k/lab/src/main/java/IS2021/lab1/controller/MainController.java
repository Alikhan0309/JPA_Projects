package IS2021.lab1.controller;

import IS2021.lab1.models.*;
import IS2021.lab1.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class MainController {

    private final KatysushlarTizimiRepository katysushlarTizimiRepository;
    private final VidKvartirRepository vidKvartirRepository;
    private final KatysushlarSanatyRepository katysushlarSanatyRepository;
    private final BagdarlamaTurleriRepository bagdarlamaTurleriRepository;
    private final VidyBankaRepository vidyBankaRepository;
    private final ZastroishikiRepository zastroishikiRepository;
    private final AimaktarRepository aimaktarRepository;

    @Autowired
    public MainController(
            KatysushlarTizimiRepository katysushlarTizimiRepository,
            VidKvartirRepository vidKvartirRepository,
            KatysushlarSanatyRepository katysushlarSanatyRepository,
            BagdarlamaTurleriRepository bagdarlamaTurleriRepository,
            VidyBankaRepository vidyBankaRepository,
            ZastroishikiRepository zastroishikiRepository,
            AimaktarRepository aimaktarRepository) {

        this.katysushlarTizimiRepository = katysushlarTizimiRepository;
        this.vidKvartirRepository = vidKvartirRepository;
        this.katysushlarSanatyRepository = katysushlarSanatyRepository;
        this.bagdarlamaTurleriRepository = bagdarlamaTurleriRepository;
        this.vidyBankaRepository = vidyBankaRepository;
        this.zastroishikiRepository = zastroishikiRepository;
        this.aimaktarRepository = aimaktarRepository;
    }

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/katysushlarTizimi")
    public String getKatysushlarTizimi(Model model) {
        List<KatysushlarTizimi> katysushlarTizimiList = katysushlarTizimiRepository.findAll();
        model.addAttribute("katysushlarTizimiList", katysushlarTizimiList);
        List<Object[]> aldy = katysushlarTizimiRepository.kansha_adam_ui_aldy();
        List<Object[]> almady = katysushlarTizimiRepository.kansha_adam_ui_almady();
        List<Object[]> select = katysushlarTizimiRepository.queryForTizim();
        List<Object[]> cursor = katysushlarTizimiRepository.get_cursor();
        model.addAttribute("cursor",cursor);
        model.addAttribute("select",select);
        model.addAttribute("aldy",aldy);
        model.addAttribute("almady",almady);
        return "/katysushlarTizimi";

    }
    @GetMapping("/dataForModalAlmady")
    @ResponseBody
    public ResponseEntity<Integer> getDataForModalAlmady() {
        List<Object[]> data = katysushlarTizimiRepository.kansha_adam_ui_almady();
        if (data.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            Integer count = ((Number) data.get(0)[0]).intValue(); // Assuming data structure correctly
            return ResponseEntity.ok(count);
        }
    }

    @GetMapping("/dataForModalAldy")
    @ResponseBody
    public ResponseEntity<Integer> getDataForModalAldy() {
        List<Object[]> data = katysushlarTizimiRepository.kansha_adam_ui_aldy();
        if (data.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            Integer count = ((Number) data.get(0)[0]).intValue(); // Assuming data structure correctly
            return ResponseEntity.ok(count);
        }
    }

    @PostMapping("/katysushlarTizimi/insert")
    public String addKatysushlarTizimi(@ModelAttribute KatysushlarTizimi katysushlarTizimi, RedirectAttributes redirectAttributes) {
        try {
            katysushlarTizimiRepository.save(katysushlarTizimi);
        } catch (Exception e) {
            String errorMessage = "Ошибка при сохранении записи.Если у человека уже есть имущество то он может быть в этой очереди по причине не сответствии условии";
            redirectAttributes.addFlashAttribute("errorMessage", errorMessage);
            return "redirect:/katysushlarTizimi";
        }
        return "redirect:/katysushlarTizimi";
    }

    @PostMapping("/katysushlarTizimi/updateKT")
    public String updateKatysushlarTizimi(@ModelAttribute KatysushlarTizimi katysushlarTizimi) {
        katysushlarTizimiRepository.save(katysushlarTizimi);
        return "redirect:/katysushlarTizimi";
    }

    @PostMapping("/katysushlarTizimi/delete/{id}")
    public String deleteKatysushlarTizimi(@PathVariable Long id) {
        katysushlarTizimiRepository.deleteById(id);
        return "redirect:/katysushlarTizimi";
    }

    @GetMapping("/vidKvartir")
    public String getVidKvartir(Model model) {
        List<VidKvartir> vidKvartirList = vidKvartirRepository.findAll();
        model.addAttribute("vidKvartir", vidKvartirList);
        return "/vidKvartir";
    }

    @PostMapping("/vidKvartir/insert")
    public String addVidKvartir(@ModelAttribute VidKvartir vidKvartir) {
        vidKvartirRepository.save(vidKvartir);
        return "redirect:/vidKvartir";
    }

    @PostMapping("/vidKvartir/update")
    public String updateVidKvartir(@ModelAttribute VidKvartir vidKvartir) {
        vidKvartirRepository.save(vidKvartir);
        return "redirect:/vidKvartir";
    }

    @PostMapping("/vidKvartir/delete/{id}")
    public String deleteVidKvartir(@PathVariable Long id) {
        vidKvartirRepository.deleteById(id);
        return "redirect:/vidKvartir";
    }

    @GetMapping("/katysushlarSanaty")
    public String getKatysushlarSanaty(Model model) {
        List<KatysushlarSanaty> katysushlarSanatyList = katysushlarSanatyRepository.findAll();
        model.addAttribute("katysushlarSanaty", katysushlarSanatyList);
        return "/katysushlarSanaty";
    }

    @PostMapping("/katysushlarSanaty/insert")
    public String addKatysushlarSanaty(@ModelAttribute KatysushlarSanaty katysushlarSanaty) {
        katysushlarSanatyRepository.save(katysushlarSanaty);
        return "redirect:/katysushlarSanaty";
    }

    @PostMapping("/katysushlarSanaty/update")
    public String updateKatysushlarSanaty(@ModelAttribute KatysushlarSanaty katysushlarSanaty) {
        katysushlarSanatyRepository.save(katysushlarSanaty);
        return "redirect:/katysushlarSanaty";
    }

    @PostMapping("/katysushlarSanaty/delete/{id}")
    public String deleteKatysushlarSanaty(@PathVariable Long id) {
        katysushlarSanatyRepository.deleteById(id);
        return "redirect:/katysushlarSanaty";
    }

    @GetMapping("/bagdarlamaTurleri")
    public String getBagdarlamaTurleri(Model model) {
        List<BagdarlamaTurleri> bagdarlamaTurleriList = bagdarlamaTurleriRepository.findAll();
        model.addAttribute("bagdarlamaTurleri", bagdarlamaTurleriList);
        return "/bagdarlamaTurleri";
    }

    @PostMapping("/bagdarlamaTurleri/insert")
    public String addBagdarlamaTurleri(@ModelAttribute BagdarlamaTurleri bagdarlamaTurleri) {
        bagdarlamaTurleriRepository.save(bagdarlamaTurleri);
        return "redirect:/bagdarlamaTurleri";
    }

    @PostMapping("/bagdarlamaTurleri/update")
    public String updateBagdarlamaTurleri(@ModelAttribute BagdarlamaTurleri bagdarlamaTurleri) {
        bagdarlamaTurleriRepository.save(bagdarlamaTurleri);
        return "redirect:/bagdarlamaTurleri";
    }

    @PostMapping("/bagdarlamaTurleri/delete/{id}")
    public String deleteBagdarlamaTurleri(@PathVariable Long id) {
        bagdarlamaTurleriRepository.deleteById(id);
        return "redirect:/bagdarlamaTurleri";
    }

    @GetMapping("/vidyBanka")
    public String getVidyBanka(Model model) {
        List<VidyBanka> vidyBankaList = vidyBankaRepository.findAll();
        model.addAttribute("vidyBanka", vidyBankaList);
        return "/vidyBanka";
    }

    @PostMapping("vidyBanka/insert")
    public String addVidyBanka(@ModelAttribute VidyBanka vidyBanka) {
        vidyBankaRepository.save(vidyBanka);
        return "redirect:/vidyBanka";
    }

    @PostMapping("vidyBanka/update")
    public String updateVidyBanka(@ModelAttribute VidyBanka vidyBanka) {
        vidyBankaRepository.save(vidyBanka);
        return "redirect:/vidyBanka";
    }

    @PostMapping("/vidyBanka/delete/{id}")
    public String deleteVidyBanka(@PathVariable Long id) {
        vidyBankaRepository.deleteById(id);
        return "redirect:/vidyBanka";
    }
    @GetMapping("/zastroishiki")
    public String getZastroishiki(Model model) {
        List<Zastroishiki> zastroishikiList = zastroishikiRepository.findAll();
        model.addAttribute("zastroishiki", zastroishikiList);
        return "/zastroishiki";
    }

    @PostMapping("zastroishiki/insert")
    public String addZastroishiki(@ModelAttribute Zastroishiki zastroishiki) {
        zastroishikiRepository.save(zastroishiki);
        return "redirect:/zastroishiki";
    }

    @PostMapping("zastroishiki/update")
    public String updateZastroishiki(@ModelAttribute Zastroishiki zastroishiki) {
        zastroishikiRepository.save(zastroishiki);
        return "redirect:/zastroishiki";
    }

    @PostMapping("/zastroishiki/delete/{id}")
    public String deleteZastroishiki(@PathVariable Long id) {
        zastroishikiRepository.deleteById(id);
        return "redirect:/zastroishiki";
    }

    @GetMapping("/aimaktar")
    public String getAimaktar(Model model) {
        List<Aimaktar> aimaktarList = aimaktarRepository.findAll();
        model.addAttribute("aimaktars", aimaktarList);
        return "/aimaktar";
    }

    @PostMapping("/aimaktar/insert")
    public String addAimaktar(@ModelAttribute Aimaktar aimaktar) {
        aimaktarRepository.save(aimaktar);
        return "redirect:/aimaktar";
    }

    @PostMapping("/aimaktar/update")
    public String updateAimaktar(@ModelAttribute Aimaktar aimaktar) {
        aimaktarRepository.save(aimaktar);
        return "redirect:/aimaktar";
    }

    @PostMapping("/aimaktar/delete/{id}")
    public String deleteAimaktar(@PathVariable Long id) {
        aimaktarRepository.deleteById(id);
        return "redirect:/aimaktar";
    }

}
