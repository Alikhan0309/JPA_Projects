package IS2021.lab1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import IS2021.lab1.models.KatysushlarSanaty;

public interface KatysushlarSanatyRepository extends JpaRepository<KatysushlarSanaty, Long> {

}
