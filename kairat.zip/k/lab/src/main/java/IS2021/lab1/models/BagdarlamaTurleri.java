package IS2021.lab1.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Entity(name = "bagdarlama_turleri")
@Setter
@Getter
public class BagdarlamaTurleri {
    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "Name_Bagdarlama_turleri")
    private String name;

    // Геттеры и сеттеры
}