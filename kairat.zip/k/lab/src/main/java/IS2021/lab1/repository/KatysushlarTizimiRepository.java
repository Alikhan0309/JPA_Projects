package IS2021.lab1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import IS2021.lab1.models.KatysushlarTizimi;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface KatysushlarTizimiRepository extends JpaRepository<KatysushlarTizimi, Long> {

    @Query(value = "select * from kansha_adam_ui_almady()", nativeQuery = true)
    List<Object[]> kansha_adam_ui_almady();

    @Query(value = "select * from kansha_adam_ui_aldy_bugingi_kunge_dein()", nativeQuery = true)
    List<Object[]> kansha_adam_ui_aldy();

    @Query(value = "select a.name_aimaktar ,COUNT(kt.ID_Katysushlar_tizimi) AS katysushlar_count FROM aimaktar a LEFT JOIN Katysushlar_tizimi kt ON a.name_aimaktar = kt.Katysushy_aimak GROUP BY a.name_aimaktar", nativeQuery = true)
    List<Object[]> queryForTizim();

    @Query(value = "select * from get_katysushlar_info()", nativeQuery = true)
    List<Object[]> get_cursor();

}