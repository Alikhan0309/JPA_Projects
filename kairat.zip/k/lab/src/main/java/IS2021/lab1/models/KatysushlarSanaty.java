package IS2021.lab1.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity(name = "katysushlar_sanaty")
public class KatysushlarSanaty {
    @Id
    @Column(name = "id_katysushlar_sanaty")
    private Integer id;

    @Column(name = "name_katysushlar_sanaty")
    private String name;

    // Геттеры и сеттеры
}
