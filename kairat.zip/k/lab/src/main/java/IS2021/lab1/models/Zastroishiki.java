package IS2021.lab1.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity(name = "Zastroishiki")
public class Zastroishiki {
    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "Name_Zastroishika")
    private String name;

    // Геттеры и сеттеры
}