package IS2021.lab1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import IS2021.lab1.models.Aimaktar;

public interface AimaktarRepository extends JpaRepository<Aimaktar, Long> {
}

