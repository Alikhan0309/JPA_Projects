package IS2021.lab1.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity(name = "Vid_kvartir")
public class VidKvartir {
    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "Kolichestvo_komnat")
    private Integer numberOfRooms;

    @Column(name = "Kolichestvo_ludei")
    private String occupancy;

    // Геттеры и сеттеры
}
