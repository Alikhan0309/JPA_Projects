package IS2021.lab1.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity(name = "Vidy_banka")
public class VidyBanka {
    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "Name_Vidy_banka")
    private String name;

    // Геттеры и сеттеры
}