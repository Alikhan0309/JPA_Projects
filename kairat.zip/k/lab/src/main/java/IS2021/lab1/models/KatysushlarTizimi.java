package IS2021.lab1.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity(name = "Katysushlar_tizimi")
public class KatysushlarTizimi {
    @Id

    @Column(name = "ID_Katysushlar_tizimi")
    private Long id;

    @Column(name = "Name_Katysushlar_tizimi")
    private String name;

    @Column(name = "Katysushy_sanaty")
    private String type;

    @Column(name = "Katysushy_aimak")
    private String region;

    @Column(name = "Katysushy_vid_banka")
    private String bankType;

    @Column(name = "Bagdarlama_turi")
    private String financingType;

    @Column(name = "Zastroishik")
    private String builder;

    @Column(name = "Podacha_zaiavka_date")
    private LocalDate applicationSubmissionDate;

    @Column(name = "Polushenie_kvartiry_date")
    private LocalDate apartmentAcquisitionDate;

    @Column(name = "Kolichestvo_komnat")
    private Integer numberOfRooms;

    @Column(name = "nalichiye_imushchestva")
    private boolean nalichiyeImushchestva ;

}
