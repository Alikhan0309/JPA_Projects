package IS2021.lab1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import IS2021.lab1.models.BagdarlamaTurleri;

public interface BagdarlamaTurleriRepository extends JpaRepository<BagdarlamaTurleri, Long> {

}

