package IS2021.lab1.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter

@Entity(name = "aimaktar")
public class Aimaktar {
    @Id
    @Column(name = "id_aimaktar")
    private Integer id;

    @Column(name = "name_aimaktar")
    private String name;

    // Геттеры и сеттеры
}